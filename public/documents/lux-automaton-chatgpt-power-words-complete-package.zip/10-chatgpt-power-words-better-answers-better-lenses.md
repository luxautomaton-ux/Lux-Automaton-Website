# 10 ChatGPT Power Words: Better Answers Come From Better Lenses

**Why these viral one-word prompts can be useful—and why clear context still matters more than any so-called secret code.**

**Lux Automaton Editorial**  
**July 24, 2026 · 8 min read**

## In this story

01 — These are prompt lenses, not hidden ChatGPT commands  
02 — What each of the ten power words is trying to do  
03 — Turn one-word shortcuts into dependable business prompts  

[Discuss in the community →](#community)

The source video opens with a strong promise: type one word into ChatGPT and change the way it answers.

That idea is appealing because prompting can feel more complicated than it needs to be. A founder may know exactly what problem needs solving but still receive a vague answer. A creator may ask for content and get something generic. A small-business owner may request a plan and receive twenty ideas with no clear priority.

The ten phrases in the video offer a shortcut:

- `FIRSTPRINCIPLES`
- `YCOMBINATOR`
- `GARYVEE`
- `ELI10`
- `REDTEAM`
- `LINDYMODE`
- `80/20`
- `HUMAN`
- `ANTIADVICE`
- `UNLEARN`

They are memorable. They can also be useful.

But they are not official ChatGPT modes, product settings, or secret switches hidden inside the model.

They work—when they work—because each word suggests a **different lens** for the response.

`REDTEAM` asks for opposition.

`ELI10` asks for simpler language.

`80/20` asks for prioritization.

`FIRSTPRINCIPLES` asks the model to separate assumptions from fundamentals.

That is the real lesson.

> **A strong prompt does not only describe the task. It tells the AI how to examine the task.**

OpenAI’s own prompting guidance recommends clear, specific instructions, useful context, an explicit desired format, and iterative refinement. A one-word lens can support that process. It should not replace it.

## 01 — These are prompt lenses, not hidden ChatGPT commands

The creator associated with the video has described these words elsewhere as fun, unofficial keywords that encourage a distinct perspective or output style.

That distinction matters.

ChatGPT does not contain a documented `TRUTHMODE`, `LINDYMODE`, or `YCOMBINATOR` button. The model interprets the word using the surrounding conversation, its training, and the rest of your request.

Different models may react differently.

The same model may produce different results when:

- The task changes
- The conversation contains different context
- The word is ambiguous
- The user asks for a specific format
- The model version changes
- Another instruction conflicts with the lens

That means the shortcut should be treated as **prompt shorthand**.

### The shortcut version

```text
REDTEAM my business idea.
```

### The dependable version

```text
REDTEAM this business idea.

Goal:
Find the strongest reasons it could fail before I invest money.

Context:
I am selling a $299-per-month private AI operating system to local service businesses.

Evaluate:
1. Customer demand
2. Pricing
3. Implementation difficulty
4. Trust and privacy concerns
5. The strongest competing alternative

Output:
- Five failure risks
- Evidence or reasoning for each
- One test I can run this week
- A final go, revise, or stop recommendation
```

The second prompt gives the lens a real job.

### Why the one-word version can still help

A one-word trigger is valuable when it helps someone remember what kind of thinking is missing.

A founder may realize:

- I need criticism, not encouragement.
- I need simplicity, not more jargon.
- I need one priority, not a larger list.
- I need durable principles, not this week’s trend.
- I need to challenge the assumption underneath the plan.

The word becomes a mental button for the human—even when it is not a literal button in the software.

> **Asa’s note:** “The power is not inside the word. The power is knowing which kind of thinking the job needs.”

## 02 — What each of the ten power words is trying to do

Here is a practical translation of the ten terms from the video.

## 1. FIRSTPRINCIPLES

### What it is trying to do

Break a problem down into its basic facts, constraints, and assumptions before rebuilding the answer.

This is useful when the conversation is trapped inside “how things are normally done.”

### Quick version

```text
FIRSTPRINCIPLES: How should I launch this service?
```

### Better version

```text
Use first-principles reasoning.

Separate:
- Facts we know
- Assumptions we are making
- Constraints we cannot ignore
- Parts of the process that exist only because of tradition

Then rebuild the simplest workable launch plan from those fundamentals.
```

### Good for

- Product design
- Pricing
- Process improvement
- Automation planning
- Cost reduction
- Strategy questions

### Watch out for

Starting from fundamentals does not mean ignoring evidence, regulations, customer habits, or lessons learned by other people.

## 2. YCOMBINATOR

### What it is trying to do

Ask for an early-stage startup lens focused on customers, product-market fit, speed, experiments, and growth.

The term is an unofficial shorthand. It does not connect the response to Y Combinator or make ChatGPT an actual YC partner.

### Safer, clearer version

```text
Act as a rigorous early-stage startup advisor.

Focus on:
- A painful customer problem
- A narrow initial user
- A simple offer
- The fastest useful test
- Evidence of willingness to pay
- What should not be built yet
```

### Good for

- Startup ideas
- Minimum viable products
- Customer interviews
- Early pricing
- Launch experiments
- Founder priorities

### Watch out for

Not every business should follow venture-backed startup logic. A profitable local company may value cash flow, stability, and owner control more than hypergrowth.

## 3. GARYVEE

### What it is trying to do

Request an energetic, platform-aware content and audience-growth perspective.

A better practice is to describe the principles you want instead of asking the model to imitate a living person’s voice.

### Safer, clearer version

```text
Use a high-energy social-media operator lens.

Prioritize:
- Platform-native ideas
- Consistent publishing
- Fast repurposing
- Audience conversation
- Strong hooks
- A sustainable content volume

Do not imitate any individual person’s exact voice.
```

### Good for

- Social calendars
- Content repurposing
- Short-form video ideas
- Personal-brand planning
- Community engagement
- Distribution strategy

### Watch out for

More content is not automatically better content. The system still needs a clear audience, useful message, quality review, and a realistic publishing rhythm.

## 4. ELI10

### What it is trying to do

Explain a complex subject in language that a ten-year-old could follow.

For adults new to AI, this can remove jargon without removing the important idea.

### Better version

```text
Explain this in plain language for an intelligent adult who is new to the topic.

Use:
- Short sentences
- One everyday analogy
- No unexplained jargon
- One practical example
- A five-line summary
```

### Good for

- AI education
- Technical onboarding
- Policy explanations
- Financial concepts
- Product guides
- Workshop lessons

### Watch out for

Simple language should not become inaccurate language. Ask the model to preserve essential risks, conditions, and exceptions.

## 5. REDTEAM

### What it is trying to do

Challenge the idea, search for failure modes, and argue against the current plan.

This is one of the most useful lenses because AI assistants can sometimes sound too agreeable.

### Better version

```text
Red-team this plan.

Assume the team is excited and may be overlooking problems.

Find:
- The weakest assumption
- The strongest objection
- The easiest way this fails
- The risk that would be most expensive
- The evidence that would change your conclusion
```

### Good for

- Product decisions
- Security reviews
- Business plans
- Marketing claims
- Automation permissions
- Major purchases

### Watch out for

Criticism without a decision path can become paralysis. End with tests, mitigations, and a recommendation.

## 6. LINDYMODE

### What it is trying to do

Prefer principles, practices, or ideas that have survived for a long time over ideas that only recently became popular.

This comes from the Lindy effect: for some nonperishable things, a longer past life can suggest a longer remaining life.

### Better version

```text
Use a durability lens.

Separate:
- Principles with a long track record
- Recent tactics with limited evidence
- Trends that may be temporary
- New ideas that are genuinely enabled by new technology

Recommend a stable foundation plus one measured experiment.
```

### Good for

- Business fundamentals
- Leadership
- Customer service
- Education
- Long-term content
- Technology strategy

### Watch out for

Old does not automatically mean correct. Durable practices can survive because of habit, power, or limited alternatives. New evidence still matters.

## 7. 80/20

### What it is trying to do

Find the small number of actions most likely to produce most of the useful result.

The 80/20 rule is a prioritization heuristic, not a guaranteed mathematical split.

### Better version

```text
Apply an 80/20 lens.

From this list, identify:
- The three actions most likely to create the largest result
- The low-value tasks to pause
- The dependency that must happen first
- One action I can complete today
- One metric to track for two weeks
```

### Good for

- Weekly planning
- Sales activity
- Content strategy
- Workflow cleanup
- Feature prioritization
- Time management

### Watch out for

Efficiency is not the only value. Safety, accessibility, maintenance, relationships, and legal requirements may not look like the highest-output work, but they still matter.

## 8. HUMAN

### What it is trying to do

Make the writing feel less stiff, formulaic, or machine-generated.

The term is also written as `/human` in some prompt lists.

### Better version

```text
Rewrite this in a natural professional voice.

Use:
- Varied sentence length
- Specific examples
- Contractions where appropriate
- Clear transitions
- No generic motivational filler
- No invented personal experiences

Preserve factual accuracy and disclose AI assistance when required.
```

### Good for

- Email drafts
- Blog editing
- Social posts
- Customer communication
- Scripts
- Founder notes

### Watch out for

No prompt can guarantee that text is “undetectable,” and AI should not be used to evade disclosure, impersonate a real person, or fabricate human experience.

## 9. ANTIADVICE

### What it is trying to do

Identify popular advice that is overused, context-free, or wrong for the current situation—then replace it with something more useful.

### Better version

```text
Use an anti-advice lens.

List five pieces of common advice people give about this problem.

For each:
- Explain when it is useful
- Explain when it fails
- Show why it may not fit my situation
- Replace it with a more specific recommendation
```

### Good for

- Business myths
- Career planning
- Marketing strategy
- Productivity advice
- AI adoption
- Founder decision-making

### Watch out for

Rejecting common advice simply because it is common can become another form of shallow thinking. Test the advice against context and evidence.

## 10. UNLEARN

### What it is trying to do

Surface assumptions, habits, or beliefs that were useful before but may no longer fit the current environment.

### Better version

```text
Use an unlearning lens.

Identify:
- The assumptions behind my current plan
- Which assumptions were true five years ago
- Which may now be outdated
- What evidence would confirm or reject them
- What I should test before changing the system
```

### Good for

- AI transformation
- Career changes
- Business modernization
- Legacy workflows
- Team habits
- Technology decisions

### Watch out for

Do not discard experience just because technology changed. The goal is to update beliefs with evidence—not chase novelty.

## 03 — Turn one-word shortcuts into dependable business prompts

The strongest way to use these terms is to create a reusable **prompt-lens library**.

Do not rely on the model to guess what `LINDYMODE` or `HUMAN` means every time.

Define the lens once.

Then combine it with a complete prompt.

## The Lux Prompt Stack

Use five layers.

### 1. Task

What should the AI do?

```text
Create a launch plan for a private AI service.
```

### 2. Context

What does it need to know?

```text
The audience is local service-business owners with fewer than 20 employees. The offer includes setup, training, and monthly support.
```

### 3. Lens

How should it examine the task?

```text
Use FIRSTPRINCIPLES and REDTEAM.
```

### 4. Constraints

What rules must it follow?

```text
Do not assume venture funding. Keep startup cost below $3,000. Protect customer data. Require human approval before outreach is sent.
```

### 5. Output

What should the result look like?

```text
Return:
1. Core assumptions
2. Three launch options
3. Top five risks
4. A 14-day test
5. One recommended next action
```

That prompt is more dependable than a power word alone.

## Combine lenses carefully

Two lenses can work well together when they serve different jobs.

### FIRSTPRINCIPLES + 80/20

Break the problem down, then prioritize the highest-leverage actions.

### ELI10 + HUMAN

Explain clearly, then make the language natural and readable.

### REDTEAM + ANTIADVICE

Challenge both the specific plan and the generic advice surrounding it.

### LINDYMODE + UNLEARN

Protect durable principles while identifying assumptions that truly became outdated.

Too many lenses can conflict.

`GARYVEE`, `LINDYMODE`, `YCOMBINATOR`, `REDTEAM`, and `ELI10` in one request may pull the answer in several directions.

Choose one primary lens and, at most, one supporting lens for important work.

## Turn the ten terms into Lux Agent switches

Lux Automaton can make the idea more dependable by defining each lens inside LANA, Hermes, Lux Codex, or another agent.

For example:

```text
When the user says 80/20:
1. Confirm the desired outcome.
2. Identify the three highest-leverage actions.
3. Name what should be paused.
4. State the most important dependency.
5. End with one measurable next action.
```

The same definition can be stored in:

- A LANA system prompt
- A Hermes skill
- A Lux Codex command
- A workshop prompt card
- A team prompt library
- A Success Pack
- A customer profile
- A reusable JSON configuration

That turns a viral tip into an operating standard.

## Test the lens instead of trusting the label

For important work, run a simple comparison.

### Prompt A

Ask the question normally.

### Prompt B

Use the one-word lens.

### Prompt C

Use the full Lux Prompt Stack with the lens defined.

Compare:

- Relevance
- Clarity
- Specificity
- Accuracy
- Actionability
- Missing context
- Review time
- Whether the result changed the decision

The one-word prompt may be enough for brainstorming.

The full prompt is usually better for work that affects customers, money, systems, or public claims.

## Keep human judgment in the loop

Each lens can introduce bias.

- `YCOMBINATOR` may overvalue rapid growth.
- `GARYVEE` may overvalue publishing volume.
- `REDTEAM` may overfocus on failure.
- `LINDYMODE` may favor tradition.
- `80/20` may ignore low-frequency but high-impact risk.
- `HUMAN` may prioritize tone over precision.
- `UNLEARN` may encourage unnecessary change.

The lens should expand judgment—not replace it.

Ask:

1. What did this lens help us see?
2. What might it have hidden?
3. What evidence supports the answer?
4. Which assumptions remain uncertain?
5. Who approves the next action?

## The bigger lesson: prompting is perspective design

The most useful part of the video is not the claim that ten words make ChatGPT smarter.

The words do not add intelligence to the model.

They change the frame around the problem.

That is valuable because many weak AI results begin with an incomplete frame.

The user asks for:

> “A marketing plan.”

But does not specify:

- The audience
- The business goal
- The budget
- The channel
- The timeline
- The evidence
- The desired perspective
- The final format

A lens helps—but context completes the job.

> **“Do not hunt for magic words. Build a clear way of thinking.” — Asa Pritchard**

**Learn AI. Build Tomorrow. Change the World. — LANA**

## Your next action

Open the **10 Prompt Lenses Practice Planner** included with this article.

Choose one real business question.

Run it three ways:

1. Normal prompt
2. One-word lens
3. Full Lux Prompt Stack

Keep the version that produces the clearest, most useful, and easiest-to-review result.

**Let’s build it.**

## Source and editorial notes

- [Source video: 10 ChatGPT Power Words](https://youtu.be/ZccmYe-bF9w?si=mO89qppluFaPaZqD)
- [Creator’s published list of unofficial prompt keywords](https://www.sabrina.dev/p/secret-codes-for-chatgpt)
- [OpenAI: Prompt engineering best practices for ChatGPT](https://help.openai.com/en/articles/10032626-prompt-engineering-best-practices-for-chatgpt)
- [OpenAI: How to create a good prompt](https://help.openai.com/en/articles/4936848-how-do-i-create-a-good-prompt-for-an-ai-model)
