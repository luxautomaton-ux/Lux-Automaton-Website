LUX AUTOMATON — COMPLETE TEXT AND PUBLISHING PACKAGE
10 ChatGPT Power Words: Better Answers Come From Better Lenses

This package intentionally contains no image files. Add the separately approved cover image in your CMS when publishing.

FILES
- 10-chatgpt-power-words-better-answers-better-lenses.html
- 10-chatgpt-power-words-better-answers-better-lenses.md
- 10-prompt-lenses-practice-planner.html
- lux-10-prompt-lenses.json
- social-and-publishing-copy.txt
- sources-and-editorial-notes.txt
- README.txt

HOW TO PUBLISH
1. Upload the approved cover image separately.
2. Keep or replace the gradient text hero in the HTML.
3. Replace the community placeholder with the live Lux Automaton URL.
4. Confirm the final canonical URL.
5. The embedded YouTube player requires internet access.
6. Use the Markdown file in a CMS.
7. Open the planner in a browser to print or save as PDF.
8. Import or adapt the JSON lens pack for LANA, Hermes, Lux Codex, workshops, or Success Packs.
9. Recheck current OpenAI prompting guidance before republishing later.

CORE EDITORIAL RULE
These terms are memorable prompt lenses—not secret ChatGPT commands.
