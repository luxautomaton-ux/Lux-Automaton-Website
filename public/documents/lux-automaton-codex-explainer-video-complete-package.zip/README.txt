LUX AUTOMATON — COMPLETE BLOG PACKAGE
How Codex Can Direct an AI Explainer Video Factory

PUBLISHING FILES
- how-codex-can-direct-an-ai-explainer-video-factory.html
- how-codex-can-direct-an-ai-explainer-video-factory.md
- ai-explainer-video-production-planner.html
- lux-codex-explainer-video-workflow.json
- sample-beats.json
- social-and-publishing-copy.txt
- sources-and-editorial-notes.txt
- README.txt

VISUAL ASSETS
- 00-asset-set-preview.png
- 01-thumbnail-codex-explainer-video-factory.png
- 02-photo-beat-map-human-gate.png
- 03-photo-style-bake-off.png
- 04-photo-motion-audio-assembly-qc.png
- 05-codex-explainer-video-overview.png
- lux-automaton-logo.png

HOW TO PUBLISH
1. Keep the responsive HTML and PNG assets in the same folder.
2. Replace the community placeholder with the live Lux Automaton URL.
3. Confirm the canonical article URL.
4. The embedded YouTube player requires internet access.
5. Use the Markdown file for a CMS.
6. Open the planner in a browser to print or save as PDF.
7. Adapt the JSON workflow for Lux Codex, Hermes, Claude Code, or another agent harness.
8. Use sample-beats.json as a safe starter project.
9. Verify current model IDs, provider pricing, terms, and licensing before running the production pipeline.

VISUAL NOTE
The five new assets use approved Asa and LANA photography with an original Lux editorial paper-collage system. They are inspired by the general production technique discussed in the source, not a copy of Vox branding or exact visual trade dress.
