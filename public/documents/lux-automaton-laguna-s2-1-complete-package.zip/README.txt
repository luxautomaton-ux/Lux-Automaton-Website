LUX AUTOMATON — COMPLETE BLOG PACKAGE
Laguna S 2.1: What a Long-Horizon Coding Model Can Actually Build

PUBLISHING FILES
- laguna-s2-1-long-horizon-coding-model.html
- laguna-s2-1-long-horizon-coding-model.md
- laguna-s2-1-model-pilot-planner.html
- laguna-s2-1-model-pilot-template.json
- social-and-publishing-copy.txt
- sources-and-editorial-notes.txt
- README.txt

VISUAL ASSETS
- 00-asset-set-preview.png
- 01-thumbnail-laguna-s2-1.png
- 02-photo-long-horizon-coding-loop.png
- 03-photo-local-hardware-reality.png
- 04-photo-laguna-production-pilot.png
- 05-laguna-s2-1-overview.png
- lux-automaton-logo.png

HOW TO PUBLISH
1. Keep the responsive HTML and all PNG assets in the same folder.
2. Replace the community placeholder with the live Lux Automaton community URL.
3. Confirm the canonical article URL.
4. The embedded YouTube player requires internet access.
5. Use the Markdown version for a CMS.
6. Open the planner in a browser to print or save as PDF.
7. Adapt the JSON template for Lux Codex, Hermes, or another controlled model-routing system.
8. Recheck official model cards before publication because runtimes, quantizations, benchmark results, and support can change.

VISUAL NOTE
The five new Lux Automaton publishing assets use approved Asa and LANA photography with custom Laguna S 2.1 architecture, hardware, workflow, and production-safety panels created specifically for this article.
